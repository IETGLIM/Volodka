/* ─── Volodka RPG – Scene Definitions ─── */
/* Single-source-of-truth definitions for scenes.
 * Each SceneDefinition captures layout, colliders, lighting, and exits in one place.
 * Use sceneDefinitionGenerator.ts to produce SCENE_CONFIG and PhysicsSceneColliders entries.
 *
 * TYPE SAFETY:
 * - FloorColliderDef requires footstepMaterial (no "fs:" prefix needed)
 * - ExitDef requires unique id and uses doorwayId to link to DoorwayDef
 * - visualComponent uses literal union VisualComponentName
 * - fogEnabled flag explicitly controls fog application
 */

import type { SceneDefinition } from '@/shared/types/sceneDefinition';

/** Volodka's room — small indoor room with desk, bookshelf, bed */
export const volodka_room_def: SceneDefinition = {
  id: 'volodka_room',
  name: 'Комната Володьки',
  dimensions: [5, 3, 7],
  type: 'indoor',
  hasCeiling: true,
  defaultSpawn: [0, 0.01, 2],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 1.0,
  doorways: [
    { id: 'room_to_corridor', position: [0, 1, 3.5], width: 1.0, height: 2.2 },
  ],
  exits: [
    {
      id: 'room_to_corridor',
      targetScene: 'volodka_corridor',
      position: [0, 1, 3.5],
      spawnPosition: [0, 0.01, 4],
      spawnRotation: 0,
      label: '→ Коридор',
      doorwayId: 'room_to_corridor',
    },
  ],
  floors: [
    { type: 'cuboid', size: [2.5, 0.05, 3.5], position: [0, -0.05, 0], footstepMaterial: 'wood' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [2.5, 1.5, 0.1], position: [0, 1.5, -3.5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [2.5, 1.5, 0.1], position: [0, 1.5, 3.5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [3.5, 1.5, 0.1], position: [-2.5, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [3.5, 1.5, 0.1], position: [2.5, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [0.9, 0.375, 0.4], position: [0, 0.375, -2.5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.4, 1.0, 0.175], position: [-2.2, 1.0, 0], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.5, 0.175, 1.0], position: [1.8, 0.175, 2.0], footstepMaterial: 'wood' },
  ],
  ceilings: [
    { type: 'cuboid', size: [2.5, 0.1, 3.5], position: [0, 3.1, 0] },
  ],
  visualComponent: 'VolodkaRoomVisual',
  lights: [
    { position: [1.5, 1.3, -3.0], intensity: 3.0, color: '#00ff66', distance: 8 },
    { position: [0, 2.5, 0], intensity: 1.0, color: '#ffaa55', distance: 8 },
    { position: [-1.5, 2.0, 2.0], intensity: 0.6, color: '#6655aa', distance: 6 },
  ],
  ambientColor: '#3a3050',
  ambientIntensity: 0.8,
  groundColor: '#2a2a3e',
  fogEnabled: true,
  fog: { near: 5, far: 12 },
};

/** Street at night — outdoor scene with buildings, neon, fog */
export const street_night_def: SceneDefinition = {
  id: 'street_night',
  name: 'Улица — ночь',
  dimensions: [20, 4, 20],
  type: 'outdoor',
  hasCeiling: false,
  defaultSpawn: [0, 0.01, 0],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 1.2,
  doorways: [
    { id: 'street_to_entrance', position: [-2.0, 1, 4.0], width: 1.2, height: 2.4 },
    { id: 'street_to_cafe', position: [4.0, 1, -2.0], width: 1.0, height: 2.2 },
    { id: 'street_to_park', position: [8.0, 1, 0], width: 2.0, height: 2.5 },
    { id: 'street_to_office', position: [0, 1, -8.0], width: 1.2, height: 2.4 },
    { id: 'street_to_rooftop', position: [-6.0, 1, -6.0], width: 0.8, height: 2.0 },
    { id: 'street_to_factory', position: [-8.0, 1, 0], width: 1.5, height: 2.5 },
  ],
  exits: [
    {
      id: 'street_to_entrance',
      targetScene: 'volodka_corridor',
      position: [-2.0, 1, 4.0],
      spawnPosition: [-2.5, 0.01, -1.0],
      spawnRotation: 0,
      label: '→ Подъезд',
      doorwayId: 'street_to_entrance',
    },
    {
      id: 'street_to_cafe',
      targetScene: 'cafe_evening',
      position: [4.0, 1, -2.0],
      spawnPosition: [0, 0.01, 4],
      spawnRotation: Math.PI,
      label: '→ Кафе «Синяя яма»',
      doorwayId: 'street_to_cafe',
    },
    {
      id: 'street_to_park',
      targetScene: 'park_day',
      position: [8.0, 1, 0],
      spawnPosition: [0, 0.01, 0],
      spawnRotation: 0,
      label: '→ Парк',
      doorwayId: 'street_to_park',
    },
    {
      id: 'street_to_office',
      targetScene: 'office_day',
      position: [0, 1, -8.0],
      spawnPosition: [0, 0.01, 4],
      spawnRotation: 0,
      label: '→ Офис',
      doorwayId: 'street_to_office',
    },
    {
      id: 'street_to_rooftop',
      targetScene: 'rooftop_edge',
      position: [-6.0, 1, -6.0],
      spawnPosition: [0, 0.01, 0],
      spawnRotation: 0,
      label: '→ Крыша',
      requiredFlag: 'rooftop_unlocked',
      doorwayId: 'street_to_rooftop',
    },
    {
      id: 'street_to_factory',
      targetScene: 'abandoned_factory',
      position: [-8.0, 1, 0],
      spawnPosition: [0, 0.01, 6],
      spawnRotation: 0,
      label: '→ Завод',
      requiredFlag: 'factory_unlocked',
      doorwayId: 'street_to_factory',
    },
  ],
  floors: [
    { type: 'cuboid', size: [10, 0.05, 10], position: [0, -0.05, 0], footstepMaterial: 'concrete' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [10, 2, 0.1], position: [-10, 2, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [10, 2, 0.1], position: [10, 2, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [4, 9, 3], position: [-12, 9, -15], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [5, 11, 3], position: [12, 11, -20], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [3.5, 7.5, 2.5], position: [-15, 7.5, 5], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [4.5, 10, 3], position: [14, 10, 8], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [6, 12.5, 4], position: [0, 12.5, -25], footstepMaterial: 'concrete' },
  ],
  ceilings: [],
  visualComponent: 'StreetVisual',
  lights: [],
  ambientColor: '#1a1a2a',
  ambientIntensity: 0.45,
  groundColor: '#0e0e1e',
  fogEnabled: true,
  fog: { near: 6, far: 25 },
  transitionStyle: 'flash',
};

/** Cafe "Blue Hole" — indoor cafe with bar counter and tables */
export const cafe_evening_def: SceneDefinition = {
  id: 'cafe_evening',
  name: 'Кафе «Синяя яма»',
  dimensions: [10, 3, 10],
  type: 'indoor',
  hasCeiling: true,
  defaultSpawn: [0, 0.01, 4],
  defaultSpawnRotation: Math.PI,
  characterModelScale: 1.0,
  locomotionScale: 1.0,
  doorways: [
    { id: 'cafe_to_street', position: [0, 1, 4.5], width: 1.0, height: 2.2 },
  ],
  exits: [
    {
      id: 'cafe_to_street',
      targetScene: 'street_night',
      position: [0, 1, 4.5],
      spawnPosition: [4.0, 0.01, -2.0],
      spawnRotation: 0,
      label: '→ Улица',
      doorwayId: 'cafe_to_street',
    },
  ],
  floors: [
    { type: 'cuboid', size: [5, 0.05, 5], position: [0, -0.05, 0], footstepMaterial: 'wood' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [5, 1.5, 0.1], position: [0, 1.5, -5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [5, 1.5, 0.1], position: [0, 1.5, 5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [5, 1.5, 0.1], position: [-5, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [5, 1.5, 0.1], position: [5, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [2.5, 0.55, 0.4], position: [0, 0.55, -4.0], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.4, 0.35, 0.4], position: [-3.0, 0.35, -2.0], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.4, 0.35, 0.4], position: [3.0, 0.35, 0], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.4, 0.35, 0.4], position: [0, 0.35, 2.5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.4, 0.35, 0.4], position: [-3.0, 0.35, 1.5], footstepMaterial: 'wood' },
  ],
  ceilings: [
    { type: 'cuboid', size: [5, 0.1, 5], position: [0, 3.1, 0] },
  ],
  visualComponent: 'CafeVisual',
  lights: [
    { position: [-3, 2, 0], intensity: 2.0, color: '#4488ff', distance: 8 },
    { position: [2, 1.5, 1], intensity: 1.0, color: '#ff8844', distance: 6 },
    { position: [0, 2.5, 0], intensity: 0.8, color: '#886644', distance: 8 },
  ],
  ambientColor: '#1a2540',
  ambientIntensity: 0.6,
  groundColor: '#1e2030',
  fogEnabled: true,
  fog: { near: 5, far: 14 },
};

/** Corridor of the communal apartment — narrow indoor hallway */
export const volodka_corridor_def: SceneDefinition = {
  id: 'volodka_corridor',
  name: 'Коридор коммуналки',
  dimensions: [4, 3, 12],
  type: 'indoor',
  hasCeiling: true,
  defaultSpawn: [0, 0.01, 4],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 1.0,
  doorways: [
    { id: 'corridor_to_room', position: [0, 1, 3.5], width: 0.9, height: 2.1 },
    { id: 'corridor_to_kitchen', position: [1.4, 0.5, -1.0], width: 0.8, height: 2.0 },
    { id: 'corridor_to_street', position: [-1.4, 0.5, -1.0], width: 1.0, height: 2.2 },
  ],
  exits: [
    {
      id: 'corridor_to_room',
      targetScene: 'volodka_room',
      position: [0, 1, 3.5],
      spawnPosition: [0, 0.01, 2],
      spawnRotation: 0,
      label: '→ Комната',
      doorwayId: 'corridor_to_room',
    },
    {
      id: 'corridor_to_kitchen',
      targetScene: 'home_evening',
      position: [1.4, 0.5, -1.0],
      spawnPosition: [0, 0.01, 2],
      spawnRotation: Math.PI,
      label: '→ Кухня',
      doorwayId: 'corridor_to_kitchen',
    },
    {
      id: 'corridor_to_street',
      targetScene: 'street_night',
      position: [-1.4, 0.5, -1.0],
      spawnPosition: [0, 0.01, 0],
      spawnRotation: 0,
      label: '→ Улица',
      doorwayId: 'corridor_to_street',
    },
  ],
  floors: [
    { type: 'cuboid', size: [2, 0.05, 6], position: [0, -0.05, 0], footstepMaterial: 'wood' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [2, 1.5, 0.1], position: [0, 1.5, -6], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [2, 1.5, 0.1], position: [0, 1.5, 6], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [6, 1.5, 0.1], position: [-2, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [6, 1.5, 0.1], position: [2, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [0.6, 0.4, 0.3], position: [1.5, 0.4, 3], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.3, 0.5, 0.3], position: [-1.5, 0.5, -3], footstepMaterial: 'wood' },
  ],
  ceilings: [
    { type: 'cuboid', size: [2, 0.1, 6], position: [0, 3.1, 0] },
  ],
  visualComponent: 'VolodkaCorridorVisual',
  lights: [
    { position: [0, 2.5, 0], intensity: 1.0, color: '#ffcc66', distance: 10 },
    { position: [0, 2.5, -3], intensity: 0.6, color: '#ffeeaa', distance: 8 },
    { position: [0, 2.5, 3], intensity: 0.6, color: '#ffddaa', distance: 8 },
  ],
  ambientColor: '#2a2530',
  ambientIntensity: 0.6,
  groundColor: '#252530',
  fogEnabled: true,
  fog: { near: 4, far: 10 },
};

/** Kitchen — evening — warm indoor family space */
export const home_evening_def: SceneDefinition = {
  id: 'home_evening',
  name: 'Кухня — вечер',
  dimensions: [14, 3, 14],
  type: 'indoor',
  hasCeiling: true,
  defaultSpawn: [0, 0.01, 2],
  defaultSpawnRotation: Math.PI,
  characterModelScale: 1.0,
  locomotionScale: 1.0,
  doorways: [
    { id: 'kitchen_to_corridor', position: [0, 1, 3.5], width: 0.9, height: 2.1 },
  ],
  exits: [
    {
      id: 'kitchen_to_corridor',
      targetScene: 'volodka_corridor',
      position: [0, 1, 3.5],
      spawnPosition: [0, 0.01, 4],
      spawnRotation: 0,
      label: '→ Коридор',
      doorwayId: 'kitchen_to_corridor',
    },
  ],
  floors: [
    { type: 'cuboid', size: [7, 0.05, 7], position: [0, -0.05, 0], footstepMaterial: 'wood' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [7, 1.5, 0.1], position: [0, 1.5, -7], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [7, 1.5, 0.1], position: [0, 1.5, 7], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [7, 1.5, 0.1], position: [-7, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [7, 1.5, 0.1], position: [7, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [1.2, 0.45, 0.5], position: [0, 0.45, -5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.5, 0.8, 0.5], position: [-5, 0.8, -5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [1.0, 0.35, 0.5], position: [4, 0.35, 2], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.4, 0.3, 0.4], position: [-3, 0.3, 4], footstepMaterial: 'wood' },
  ],
  ceilings: [
    { type: 'cuboid', size: [7, 0.1, 7], position: [0, 3.1, 0] },
  ],
  visualComponent: 'HomeEveningVisual',
  lights: [
    { position: [0, 2.5, 0], intensity: 1.5, color: '#ffaa44', distance: 8 },
    { position: [-1.5, 1.5, -1], intensity: 0.8, color: '#ff8833', distance: 5 },
  ],
  ambientColor: '#4a3525',
  ambientIntensity: 0.7,
  groundColor: '#3a2a20',
  fogEnabled: true,
  fog: { near: 5, far: 11 },
};

/** Street — winter — cold outdoor scene with snow */
export const street_winter_def: SceneDefinition = {
  id: 'street_winter',
  name: 'Улица — зима',
  dimensions: [25, 4, 25],
  type: 'outdoor',
  hasCeiling: false,
  defaultSpawn: [0, 0.01, 0],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 1.1,
  doorways: [
    { id: 'winter_to_entrance', position: [0, 1, 10.0], width: 1.2, height: 2.4 },
  ],
  exits: [
    {
      id: 'winter_to_entrance',
      targetScene: 'volodka_corridor',
      position: [0, 1, 10.0],
      spawnPosition: [-2.5, 0.01, -1.0],
      spawnRotation: 0,
      label: '→ Подъезд',
      doorwayId: 'winter_to_entrance',
    },
  ],
  floors: [
    { type: 'cuboid', size: [12.5, 0.05, 12.5], position: [0, -0.05, 0], footstepMaterial: 'snow' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [12.5, 2, 0.1], position: [-12.5, 2, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [12.5, 2, 0.1], position: [12.5, 2, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [3, 8, 2.5], position: [-14, 8, -12], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [4, 10, 3], position: [15, 10, -8], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [2.5, 6, 2], position: [-16, 6, 8], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [3.5, 9, 2.5], position: [13, 9, 10], footstepMaterial: 'concrete' },
  ],
  ceilings: [],
  visualComponent: 'StreetWinterVisual',
  lights: [
    { position: [0, 3, 0], intensity: 1.2, color: '#c8d8f0', distance: 20 },
    { position: [-6, 2, -6], intensity: 0.5, color: '#aabbdd', distance: 12 },
    { position: [6, 2, 6], intensity: 0.5, color: '#aabbdd', distance: 12 },
  ],
  ambientColor: '#c0c8d8',
  ambientIntensity: 0.6,
  groundColor: '#d0d8e8',
  fogEnabled: true,
  fog: { near: 3, far: 18 },
  transitionStyle: 'flash',
};

/** IT Guild Office — bright indoor workspace */
export const office_day_def: SceneDefinition = {
  id: 'office_day',
  name: 'Офис IT-гильдии',
  dimensions: [14, 3, 12],
  type: 'indoor',
  hasCeiling: true,
  defaultSpawn: [0, 0.01, 4],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 1.0,
  doorways: [
    { id: 'office_to_street', position: [0, 1, 5.5], width: 1.2, height: 2.4 },
  ],
  exits: [
    {
      id: 'office_to_street',
      targetScene: 'street_night',
      position: [0, 1, 5.5],
      spawnPosition: [0, 0.01, -8.0],
      spawnRotation: 0,
      label: '→ Улица',
      doorwayId: 'office_to_street',
    },
  ],
  floors: [
    { type: 'cuboid', size: [7, 0.05, 6], position: [0, -0.05, 0], footstepMaterial: 'carpet' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [7, 1.5, 0.1], position: [0, 1.5, -6], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [7, 1.5, 0.1], position: [0, 1.5, 6], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [6, 1.5, 0.1], position: [-7, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [6, 1.5, 0.1], position: [7, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [1.2, 0.35, 0.6], position: [-4, 0.35, -3], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [1.2, 0.35, 0.6], position: [-2, 0.35, -3], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [1.2, 0.35, 0.6], position: [2, 0.35, -3], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [1.2, 0.35, 0.6], position: [4, 0.35, -3], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [2.0, 0.8, 0.5], position: [0, 0.8, 0], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.8, 0.35, 0.8], position: [-5, 0.35, 3], footstepMaterial: 'wood' },
  ],
  ceilings: [
    { type: 'cuboid', size: [7, 0.1, 6], position: [0, 3.1, 0] },
  ],
  visualComponent: 'OfficeVisual',
  lights: [
    { position: [0, 2.8, 0], intensity: 2.0, color: '#ffffff', distance: 12 },
    { position: [-4, 2.5, -2], intensity: 1.0, color: '#eef4ff', distance: 8 },
    { position: [4, 2.5, -2], intensity: 1.0, color: '#eef4ff', distance: 8 },
  ],
  ambientColor: '#e0e8f0',
  ambientIntensity: 0.7,
  groundColor: '#c8d0d8',
  fogEnabled: true,
  fog: { near: 8, far: 18 },
};

/** Park — day — open outdoor green space */
export const park_day_def: SceneDefinition = {
  id: 'park_day',
  name: 'Парк — день',
  dimensions: [30, 4, 30],
  type: 'outdoor',
  hasCeiling: false,
  defaultSpawn: [0, 0.01, 0],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 1.3,
  doorways: [
    { id: 'park_to_street', position: [-12.0, 1, 0], width: 2.0, height: 2.5 },
    { id: 'park_to_library', position: [0, 1, -12.0], width: 1.0, height: 2.2 },
  ],
  exits: [
    {
      id: 'park_to_street',
      targetScene: 'street_night',
      position: [-12.0, 1, 0],
      spawnPosition: [8.0, 0.01, 0],
      spawnRotation: 0,
      label: '→ Улица',
      doorwayId: 'park_to_street',
    },
    {
      id: 'park_to_library',
      targetScene: 'library_day',
      position: [0, 1, -12.0],
      spawnPosition: [0, 0.01, 5],
      spawnRotation: Math.PI,
      label: '→ Библиотека',
      doorwayId: 'park_to_library',
    },
  ],
  floors: [
    { type: 'cuboid', size: [15, 0.05, 15], position: [0, -0.05, 0], footstepMaterial: 'grass' },
  ],
  walls: [],
  obstacles: [
    { type: 'cuboidObstacle', size: [1.0, 2.5, 1.0], position: [-6, 2.5, -4], footstepMaterial: 'grass' },
    { type: 'cuboidObstacle', size: [0.8, 3.0, 0.8], position: [4, 3.0, -8], footstepMaterial: 'grass' },
    { type: 'cuboidObstacle', size: [1.2, 2.0, 1.2], position: [10, 2.0, 6], footstepMaterial: 'grass' },
    { type: 'cuboidObstacle', size: [0.9, 2.8, 0.9], position: [-10, 2.8, 8], footstepMaterial: 'grass' },
    { type: 'cuboidObstacle', size: [1.5, 0.4, 1.5], position: [0, 0.4, 5], footstepMaterial: 'stone' },
    { type: 'cuboidObstacle', size: [3.0, 0.35, 1.0], position: [-3, 0.35, 0], footstepMaterial: 'stone' },
  ],
  ceilings: [],
  visualComponent: 'ParkVisual',
  lights: [
    { position: [0, 3.5, 0], intensity: 2.0, color: '#ffffee', distance: 30 },
    { position: [-8, 3, -5], intensity: 0.8, color: '#aaffaa', distance: 15 },
    { position: [8, 3, 5], intensity: 0.8, color: '#aaffaa', distance: 15 },
  ],
  ambientColor: '#a0c0a0',
  ambientIntensity: 0.65,
  groundColor: '#3a5a2a',
  fogEnabled: true,
  fog: { near: 10, far: 40 },
  transitionStyle: 'flash',
};

/** Library — day — quiet indoor study space with bookshelves */
export const library_day_def: SceneDefinition = {
  id: 'library_day',
  name: 'Библиотека',
  dimensions: [16, 3, 14],
  type: 'indoor',
  hasCeiling: true,
  defaultSpawn: [0, 0.01, 5],
  defaultSpawnRotation: Math.PI,
  characterModelScale: 1.0,
  locomotionScale: 0.9,
  doorways: [
    { id: 'library_to_park', position: [0, 1, 6.0], width: 1.0, height: 2.2 },
  ],
  exits: [
    {
      id: 'library_to_park',
      targetScene: 'park_day',
      position: [0, 1, 6.0],
      spawnPosition: [0, 0.01, -12.0],
      spawnRotation: 0,
      label: '→ Парк',
      doorwayId: 'library_to_park',
    },
  ],
  floors: [
    { type: 'cuboid', size: [8, 0.05, 7], position: [0, -0.05, 0], footstepMaterial: 'wood' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [8, 1.5, 0.1], position: [0, 1.5, -7], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [8, 1.5, 0.1], position: [0, 1.5, 7], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [7, 1.5, 0.1], position: [-8, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [7, 1.5, 0.1], position: [8, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [2.5, 1.2, 0.4], position: [-5, 1.2, -4], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [2.5, 1.2, 0.4], position: [-5, 1.2, 0], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [2.5, 1.2, 0.4], position: [5, 1.2, -4], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [2.5, 1.2, 0.4], position: [5, 1.2, 0], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [1.5, 0.35, 0.8], position: [0, 0.35, 3], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [1.5, 0.35, 0.8], position: [0, 0.35, -2], footstepMaterial: 'wood' },
  ],
  ceilings: [
    { type: 'cuboid', size: [8, 0.1, 7], position: [0, 3.1, 0] },
  ],
  visualComponent: 'LibraryVisual',
  lights: [
    { position: [0, 2.8, 0], intensity: 1.5, color: '#ffeecc', distance: 12 },
    { position: [-5, 2.0, -2], intensity: 0.8, color: '#ffddaa', distance: 8 },
    { position: [5, 2.0, -2], intensity: 0.8, color: '#ffddaa', distance: 8 },
  ],
  ambientColor: '#d8c8a0',
  ambientIntensity: 0.5,
  groundColor: '#8a7a50',
  fogEnabled: true,
  fog: { near: 6, far: 16 },
};

/** Battle arena — combat encounter space */
export const battle_def: SceneDefinition = {
  id: 'battle',
  name: 'Бой',
  dimensions: [12, 3, 12],
  type: 'outdoor',
  hasCeiling: false,
  defaultSpawn: [0, 0.01, 3],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 1.0,
  doorways: [
    { id: 'battle_to_street', position: [0, 1, 5.5], width: 1.2, height: 2.4 },
  ],
  exits: [
    {
      id: 'battle_to_street',
      targetScene: 'street_night',
      position: [0, 1, 5.5],
      spawnPosition: [0, 0.01, 0],
      spawnRotation: 0,
      label: '→ Улица',
      doorwayId: 'battle_to_street',
    },
  ],
  floors: [
    { type: 'cuboid', size: [6, 0.05, 6], position: [0, -0.05, 0], footstepMaterial: 'concrete' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [6, 1.5, 0.1], position: [0, 1.5, -6], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [6, 1.5, 0.1], position: [0, 1.5, 6], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [6, 1.5, 0.1], position: [-6, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [6, 1.5, 0.1], position: [6, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [0.8, 0.5, 0.8], position: [-3, 0.5, -3], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [0.8, 0.5, 0.8], position: [3, 0.5, -3], footstepMaterial: 'concrete' },
  ],
  ceilings: [],
  visualComponent: 'BattleVisual',
  lights: [
    { position: [0, 2.5, 0], intensity: 2.5, color: '#ff4444', distance: 10 },
    { position: [-4, 2.0, -4], intensity: 0.8, color: '#ff6644', distance: 8 },
    { position: [4, 2.0, -4], intensity: 0.8, color: '#ff6644', distance: 8 },
  ],
  ambientColor: '#3a1a1a',
  ambientIntensity: 0.5,
  groundColor: '#1a0a0a',
  fogEnabled: true,
  fog: { near: 5, far: 15 },
};

/** Dream — surreal subconscious landscape */
export const sleep_dream_def: SceneDefinition = {
  id: 'sleep_dream',
  name: 'Сон',
  dimensions: [50, 4, 50],
  type: 'dream',
  hasCeiling: false,
  defaultSpawn: [0, 0.01, 0],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 1.5,
  doorways: [],
  exits: [
    {
      id: 'dream_to_room',
      targetScene: 'volodka_room',
      position: [0, 1, 0],
      spawnPosition: [0, 0.01, 2],
      spawnRotation: 0,
      label: '→ Проснуться',
    },
  ],
  floors: [
    { type: 'cuboid', size: [25, 0.05, 25], position: [0, -0.05, 0], footstepMaterial: 'dream' },
  ],
  walls: [],
  obstacles: [
    { type: 'cuboidObstacle', size: [2, 4, 2], position: [-10, 4, -10], footstepMaterial: 'dream' },
    { type: 'cuboidObstacle', size: [3, 6, 1], position: [15, 6, -15], footstepMaterial: 'dream' },
    { type: 'cuboidObstacle', size: [1.5, 3, 1.5], position: [8, 3, 12], footstepMaterial: 'dream' },
    { type: 'cuboidObstacle', size: [2, 5, 2], position: [-18, 5, 8], footstepMaterial: 'dream' },
  ],
  ceilings: [],
  visualComponent: 'DreamVisual',
  lights: [
    { position: [0, 3, 0], intensity: 1.5, color: '#aa44ff', distance: 25 },
    { position: [-12, 2, -12], intensity: 0.6, color: '#44aaff', distance: 15 },
    { position: [12, 2, 12], intensity: 0.6, color: '#44aaff', distance: 15 },
    { position: [0, 2, 0], intensity: 0.4, color: '#ff44aa', distance: 10 },
  ],
  ambientColor: '#2a1a40',
  ambientIntensity: 0.4,
  groundColor: '#1a1525',
  fogEnabled: true,
  fog: { near: 2, far: 30 },
  transitionStyle: 'ripple',
};

/** Rooftop edge — precarious outdoor perch above the city */
export const rooftop_edge_def: SceneDefinition = {
  id: 'rooftop_edge',
  name: 'Край крыши',
  dimensions: [10, 3, 8],
  type: 'outdoor',
  hasCeiling: false,
  defaultSpawn: [0, 0.01, 0],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 0.8,
  doorways: [
    { id: 'rooftop_to_street', position: [0, 1, 3.5], width: 0.8, height: 2.0 },
  ],
  exits: [
    {
      id: 'rooftop_to_street',
      targetScene: 'street_night',
      position: [0, 1, 3.5],
      spawnPosition: [-6.0, 0.01, -6.0],
      spawnRotation: 0,
      label: '→ Улица',
      requiredFlag: 'rooftop_unlocked',
      doorwayId: 'rooftop_to_street',
    },
  ],
  floors: [
    { type: 'cuboid', size: [5, 0.05, 4], position: [0, -0.05, -1], footstepMaterial: 'concrete' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [5, 1.0, 0.1], position: [0, 1.0, 3.5], footstepMaterial: 'concrete' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [1.0, 0.6, 0.6], position: [-3, 0.6, -2], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [0.6, 0.4, 0.6], position: [3, 0.4, 0], footstepMaterial: 'concrete' },
  ],
  ceilings: [],
  visualComponent: 'RooftopVisual',
  lights: [
    { position: [0, 2.5, -1], intensity: 0.5, color: '#ff8844', distance: 10 },
    { position: [-4, 1, -3], intensity: 0.3, color: '#4488ff', distance: 8 },
    { position: [4, 1, -3], intensity: 0.3, color: '#4488ff', distance: 8 },
  ],
  ambientColor: '#2a2040',
  ambientIntensity: 0.3,
  groundColor: '#1a1a2e',
  fogEnabled: true,
  fog: { near: 15, far: 80 },
  transitionStyle: 'darken',
};

/** Abandoned factory — dark industrial interior */
export const abandoned_factory_def: SceneDefinition = {
  id: 'abandoned_factory',
  name: 'Заброшенный завод',
  dimensions: [20, 4, 18],
  type: 'indoor',
  hasCeiling: true,
  defaultSpawn: [0, 0.01, 6],
  defaultSpawnRotation: 0,
  characterModelScale: 1.0,
  locomotionScale: 1.1,
  doorways: [
    { id: 'factory_to_street', position: [0, 1, 8.0], width: 1.5, height: 2.5 },
  ],
  exits: [
    {
      id: 'factory_to_street',
      targetScene: 'street_night',
      position: [0, 1, 8.0],
      spawnPosition: [-8.0, 0.01, 0],
      spawnRotation: 0,
      label: '→ Улица',
      requiredFlag: 'factory_unlocked',
      doorwayId: 'factory_to_street',
    },
  ],
  floors: [
    { type: 'cuboid', size: [10, 0.05, 9], position: [0, -0.05, 0], footstepMaterial: 'concrete' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [10, 2, 0.1], position: [0, 2, -9], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [10, 2, 0.1], position: [0, 2, 9], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [9, 2, 0.1], position: [-10, 2, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [9, 2, 0.1], position: [10, 2, 0], rotation: Math.PI / 2, footstepMaterial: 'concrete' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [2.5, 1.5, 1.5], position: [-6, 1.5, -5], footstepMaterial: 'metal' },
    { type: 'cuboidObstacle', size: [3.0, 2.0, 2.0], position: [5, 2.0, -4], footstepMaterial: 'metal' },
    { type: 'cuboidObstacle', size: [1.5, 1.0, 1.0], position: [-3, 1.0, 3], footstepMaterial: 'metal' },
    { type: 'cuboidObstacle', size: [4.0, 0.4, 1.0], position: [2, 0.4, 4], footstepMaterial: 'concrete' },
    { type: 'cuboidObstacle', size: [1.0, 3.0, 1.0], position: [7, 3.0, 2], footstepMaterial: 'metal' },
  ],
  ceilings: [
    { type: 'cuboid', size: [10, 0.1, 9], position: [0, 4.1, 0] },
  ],
  visualComponent: 'FactoryVisual',
  lights: [
    { position: [0, 3.5, 0], intensity: 0.8, color: '#ffaa44', distance: 14 },
    { position: [-6, 2, -4], intensity: 0.5, color: '#ff6622', distance: 8 },
    { position: [6, 2, 4], intensity: 0.4, color: '#ff8844', distance: 8 },
  ],
  ambientColor: '#2a2520',
  ambientIntensity: 0.55,
  groundColor: '#25221e',
  fogEnabled: true,
  fog: { near: 4, far: 16 },
  transitionStyle: 'darken',
};

/** Zarema & Albert's room — cozy indoor shared room */
export const zarema_albert_room_def: SceneDefinition = {
  id: 'zarema_albert_room',
  name: 'Комната Заремы и Альберта',
  dimensions: [8, 3, 8],
  type: 'indoor',
  hasCeiling: true,
  defaultSpawn: [0, 0.01, 2],
  defaultSpawnRotation: Math.PI,
  characterModelScale: 1.0,
  locomotionScale: 1.0,
  doorways: [
    { id: 'zarema_to_corridor', position: [0, 1, 3.5], width: 0.9, height: 2.1 },
  ],
  exits: [
    {
      id: 'zarema_to_corridor',
      targetScene: 'volodka_corridor',
      position: [0, 1, 3.5],
      spawnPosition: [0, 0.01, 4],
      spawnRotation: 0,
      label: '→ Коридор',
      doorwayId: 'zarema_to_corridor',
    },
  ],
  floors: [
    { type: 'cuboid', size: [4, 0.05, 4], position: [0, -0.05, 0], footstepMaterial: 'wood' },
  ],
  walls: [
    { type: 'cuboidObstacle', size: [4, 1.5, 0.1], position: [0, 1.5, -4], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [4, 1.5, 0.1], position: [0, 1.5, 4], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [4, 1.5, 0.1], position: [-4, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [4, 1.5, 0.1], position: [4, 1.5, 0], rotation: Math.PI / 2, footstepMaterial: 'wood' },
  ],
  obstacles: [
    { type: 'cuboidObstacle', size: [0.9, 0.375, 0.4], position: [-2, 0.375, -2.5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.9, 0.375, 0.4], position: [2, 0.375, -2.5], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.4, 1.0, 0.175], position: [3.2, 1.0, 0], footstepMaterial: 'wood' },
    { type: 'cuboidObstacle', size: [0.5, 0.175, 1.0], position: [-3.0, 0.175, 2.0], footstepMaterial: 'wood' },
  ],
  ceilings: [
    { type: 'cuboid', size: [4, 0.1, 4], position: [0, 3.1, 0] },
  ],
  visualComponent: 'ZaremaAlbertVisual',
  lights: [
    { position: [0, 2.5, 0], intensity: 1.0, color: '#ffcc88', distance: 8 },
    { position: [-2, 1.5, -2], intensity: 0.6, color: '#ffaa66', distance: 5 },
    { position: [2, 1.5, -2], intensity: 0.6, color: '#ffaa66', distance: 5 },
  ],
  ambientColor: '#3a3028',
  ambientIntensity: 0.65,
  groundColor: '#2e2820',
  fogEnabled: true,
  fog: { near: 5, far: 12 },
};

/** Map of all scene definitions — single source of truth */
export const SCENE_DEFINITIONS: Record<string, SceneDefinition> = {
  volodka_room: volodka_room_def,
  volodka_corridor: volodka_corridor_def,
  home_evening: home_evening_def,
  street_night: street_night_def,
  street_winter: street_winter_def,
  cafe_evening: cafe_evening_def,
  office_day: office_day_def,
  park_day: park_day_def,
  library_day: library_day_def,
  battle: battle_def,
  sleep_dream: sleep_dream_def,
  rooftop_edge: rooftop_edge_def,
  abandoned_factory: abandoned_factory_def,
  zarema_albert_room: zarema_albert_room_def,
};
